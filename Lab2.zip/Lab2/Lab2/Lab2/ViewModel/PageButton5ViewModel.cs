﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using Xamarin.Forms;

namespace Lab2.ViewModel
{
    class PageButton5ViewModel
    {
        #region Constructor
        public PageButton5ViewModel()
        {
            //Command
            Button5Command = new Command(GetButton5);
        }
        #endregion


        #region Property

        #endregion

        #region Method
        private void GetButton5()
        {
            Application.Current.MainPage.Navigation.PopAsync();
        }

        #endregion

        #region Command
        public Command Button5Command { get; }
        #endregion

        #region Property Inteface
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        #endregion
    }
}
