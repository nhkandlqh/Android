﻿using Lab2.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text;
using Xamarin.Forms;

namespace Lab2.ViewModel
{
    class MainViewModel : INotifyPropertyChanged
    {
        public MainViewModel()
        {
            //Set property



            //Method


            //Command
            Button1Command = new Command(GotoPageButton1);
            Button2Command = new Command(GotoPageButton2);
            Button3Command = new Command(GotoPageButton3);
            Button4Command = new Command(GotoPageButton4);
            Button5Command = new Command(GotoPageButton5);
        }

        #region Method
        private async void GotoPageButton1()
        {
            await App.Current.MainPage.Navigation.PushAsync(new NavigationPage(new PageButton1()));
        }

        private async void GotoPageButton2()
        {
            await App.Current.MainPage.Navigation.PushAsync(new NavigationPage(new PageButton2()));
        }

        private async void GotoPageButton3()
        {
            await App.Current.MainPage.Navigation.PushAsync(new NavigationPage(new PageButton3()));
        }

        private async void GotoPageButton4()
        {
            await App.Current.MainPage.Navigation.PushAsync(new NavigationPage(new PageButton4()));
        }

        private async void GotoPageButton5()
        {
            await App.Current.MainPage.Navigation.PushAsync(new NavigationPage(new PageButton5()));
        }
        #endregion

        #region Command
        public Command Button1Command { get; }
        public Command Button2Command { get; }
        public Command Button3Command { get; }
        public Command Button4Command { get; }
        public Command Button5Command { get; }
        #endregion

        #region Property Inteface
        public event PropertyChangedEventHandler PropertyChanged;
        void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
        #endregion
    }
}
